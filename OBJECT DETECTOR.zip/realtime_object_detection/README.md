# realtime_object_detection

in refrence to tutorial: https://youtu.be/zs43IrWTzB0
